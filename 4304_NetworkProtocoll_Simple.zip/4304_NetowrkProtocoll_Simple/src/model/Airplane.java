package model;

import java.io.Serializable;

public class Airplane implements Serializable {
    private static final long serialVersionUID = -4193513658806463873L;
    private String name, manufacturer;
    private int seats;

    public Airplane(String name, int seats, String manufacturer) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.seats = seats;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    @Override
    public String toString() {
        return "Airplane{" +
                "name='" + name + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", seats=" + seats +
                '}';
    }
}
