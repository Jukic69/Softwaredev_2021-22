package server;

import common.Communicator;
import common.ObjectCommunicator;
import common.Reservation;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Server {
    private static final int PORT = 6666;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT);){
            Collection<Reservation> reservations = Collections.synchronizedCollection(new HashSet<>());

            Executor executor = Executors.newFixedThreadPool(10);

            while (true) {
                Socket socket = serverSocket.accept();
                Communicator objectCommunicator = new ObjectCommunicator(
                        socket.getInputStream(),
                        socket.getOutputStream());

                executor.execute(new ClientHandler(socket, objectCommunicator, reservations));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
