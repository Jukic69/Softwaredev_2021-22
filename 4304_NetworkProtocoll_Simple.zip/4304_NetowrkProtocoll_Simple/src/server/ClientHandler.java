package server;
import common.*;
import java.io.IOException;
import java.net.Socket;
import java.util.Collection;

public class ClientHandler implements Runnable{
    private Collection<Reservation> reservations;
    private Communicator communicator;
    private Socket socket;

    public ClientHandler(Socket socket, Communicator communicator, Collection<Reservation> reservations){
        this.communicator = communicator;
        this.socket = socket;
        this.reservations = reservations;
    }

    @Override
    public void run() {
        boolean quit = false;
        Response response = null;
        Reservation reservation;

        try {
            while (!quit) {
                Request request = (Request) communicator.receive();
                reservation = request.getReservation();

                synchronized (reservations) {
                    switch (request.getCommand()) {
                        case RESERVE:
                            if (reservations.contains(reservation))
                                response = new Response(Status.TAKEN, reservation);
                            else {
                                response = new Response(Status.OK, reservation);
                                reservations.add(reservation);
                            }
                            break;
                        case QUERY:
                            if (reservations.contains(reservation))
                                response = new Response(Status.TAKEN, reservation);
                            else
                                response = new Response(Status.AVAILABLE, reservation);
                            break;
                        case CANCEL:
                            if (reservations.contains(reservation)) {
                                reservations.remove(reservation);
                                response = new Response(Status.OK, reservation);
                            } else {
                                response = new Response(Status.FAIL, reservation);
                            }
                            break;
                        case QUIT:
                            response = new Response(Status.OK, null);
                            quit = true;
                            break;
                        default:
                            response = new Response(Status.FAIL, null);
                            break;
                    }
                }
                communicator.send(response);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}