package common;

import model.Airplane;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Collection;

public class ObjectTransmitter implements Transmitter{
    @Override
    public Collection<Airplane> receive(Socket s) throws Exception {
        try (ObjectInputStream ois = new ObjectInputStream(s.getInputStream())){
            return (Collection<Airplane>) ois.readObject();
        }
    }

    @Override
    public void send(Collection<Airplane> airplane, Socket s) throws Exception {
        try (ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream())){
            oos.writeObject(airplane);
        }
    }
}
