package common;

public class Response implements Packet {
    private static final long serialVersionUID = 1846453893794015685L;
    private Status status;
    private Reservation reservation;

    public Response(Status status, Reservation reservation) {
        this.status = status;
        this.reservation = reservation;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Reservation getReservation() {
        return reservation;
    }

    public void setReservation(Reservation reservation) {
        this.reservation = reservation;
    }

    @Override
    public String toString() {
        return "Response{" +
                "status=" + status +
                ", reservation=" + reservation +
                '}';
    }
}
