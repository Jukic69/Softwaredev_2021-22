package common;

import java.io.Serializable;

public enum Command implements Serializable {
    RESERVE, CANCEL, QUERY, QUIT;
}