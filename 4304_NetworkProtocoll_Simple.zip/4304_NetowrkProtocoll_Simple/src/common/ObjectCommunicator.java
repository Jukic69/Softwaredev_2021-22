package common;

import java.io.*;

public class ObjectCommunicator implements Communicator{
    private ObjectOutputStream oos;
    private ObjectInputStream ois;

    public ObjectCommunicator(InputStream is, OutputStream os) throws IOException {
        oos = new ObjectOutputStream(os);
        ois = new ObjectInputStream(is);
    }

    @Override
    public void send(Packet pack) throws IOException {
        oos.writeObject(pack);
    }

    @Override
    public Packet receive() throws IOException, ClassNotFoundException {
        return (Packet) ois.readObject();
    }
}
