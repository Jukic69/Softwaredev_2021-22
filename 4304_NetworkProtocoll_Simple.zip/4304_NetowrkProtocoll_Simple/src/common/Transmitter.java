package common;

import model.Airplane;

import java.net.Socket;
import java.util.Collection;

public interface Transmitter {
    Collection<Airplane> receive (Socket s) throws Exception;
    void send (Collection<Airplane> airplane, Socket s) throws Exception;
}
