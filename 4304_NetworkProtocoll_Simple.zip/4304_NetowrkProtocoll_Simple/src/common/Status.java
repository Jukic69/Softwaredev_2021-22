package common;

import java.io.Serializable;

public enum Status implements Serializable {
    OK, AVAILABLE, TAKEN, FAIL;
}