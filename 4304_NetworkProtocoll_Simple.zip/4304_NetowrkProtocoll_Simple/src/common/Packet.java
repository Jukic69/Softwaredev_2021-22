package common;

import java.io.Serializable;

public interface Packet extends Serializable {
}
