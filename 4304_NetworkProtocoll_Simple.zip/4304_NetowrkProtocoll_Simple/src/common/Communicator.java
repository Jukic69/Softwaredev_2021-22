package common;

import java.io.IOException;

public interface Communicator {
    void send(Packet packet) throws IOException;
    Packet receive() throws IOException, ClassNotFoundException;
}