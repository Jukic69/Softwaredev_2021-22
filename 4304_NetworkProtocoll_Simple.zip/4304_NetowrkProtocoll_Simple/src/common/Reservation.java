package common;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Reservation implements Packet {
    private static final long serialVersionUID = 1991748655680640305L;
    private String name;
    private int tableNo;
    private LocalDateTime reservationTime;


    public Reservation(String name, int tableNo, LocalDateTime reservationTime) {
        this.name = name;
        this.tableNo = tableNo;
        this.reservationTime = reservationTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTableNo() {
        return tableNo;
    }

    public void setTableNo(int tableNo) {
        this.tableNo = tableNo;
    }

    public LocalDateTime getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(LocalDateTime reservationTime) {
        this.reservationTime = reservationTime;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "name='" + name + '\'' +
                ", tableNo=" + tableNo +
                ", reservationTime=" + reservationTime +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Reservation that = (Reservation) o;

        if (tableNo != that.tableNo) return false;
        return reservationTime != null ? reservationTime.equals(that.reservationTime) : that.reservationTime == null;
    }

    @Override
    public int hashCode() {
        int result = tableNo;
        result = 31 * result + (reservationTime != null ? reservationTime.hashCode() : 0);
        return result;
    }
}