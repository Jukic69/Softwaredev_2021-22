package common;

public class Request implements Packet {
    private static final long serialVersionUID = 2151012423469952788L;
    private Command command;
    private Reservation reservation;

    public Request(Command command, Reservation reservation) {
        this.command = command;
        this.reservation = reservation;
    }

    public Command getCommand() {
        return command;
    }

    public void setCommand(Command command) {
        this.command = command;
    }

    public Reservation getReservation() {
        return reservation;
    }

    public void setReservation(Reservation reservation) {
        this.reservation = reservation;
    }

    @Override
    public String toString() {
        return "Request{" +
                "command=" + command +
                ", reservation=" + reservation +
                '}';
    }
}
