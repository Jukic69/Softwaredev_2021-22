package client;

import common.*;

import java.io.IOException;
import java.net.Socket;
import java.time.LocalDateTime;

public class Client {
    private Socket socket;
    private Communicator communicator;

    public Client(Socket socket) throws IOException {
        this.socket = socket;
        this.communicator = new ObjectCommunicator(socket.getInputStream(), socket.getOutputStream());
    }

    public Status reserve(Reservation reservation) throws IOException, ClassNotFoundException {
        Request request = new Request(Command.RESERVE, reservation);
        communicator.send(request);
        Response response = (Response) communicator.receive();
        return response.getStatus();
    }

    public Status cancel(Reservation reservation) throws IOException, ClassNotFoundException {
        Request request = new Request(Command.CANCEL, reservation);
        communicator.send(request);
        Response response = (Response) communicator.receive();
        return response.getStatus();
    }

    public Status query(Reservation reservation) throws IOException, ClassNotFoundException {
        Request request = new Request(Command.QUERY, reservation);
        communicator.send(request);
        Response response = (Response) communicator.receive();
        return response.getStatus();
    }

    public static void main(String[] args) {
        try {
            Client client = new Client(new Socket("localhost", 6666));
            LocalDateTime now = LocalDateTime.now();

            Reservation r1 = new Reservation("Helml", 1, now);
            Reservation r2 = new Reservation("HELL", 1, now);
            Reservation r3 = new Reservation("Leitner", 3, now);

            Status response = client.reserve(r1);
            System.out.println("RES " + r1 + response);

            response = client.reserve(r2);
            System.out.println("RES " + r2 + response);

            response = client.reserve(r3);
            System.out.println("RES " + r3 + response);

            response = client.query(r1);
            System.out.println("QUERY " + r1 + response);

            response = client.query(r2);
            System.out.println("QUERY " + r2 + response);

            response = client.cancel(r3);
            System.out.println("CANCEL " + r3 + response);

            response = client.query(r3);
            System.out.println("QUERY " + r3 + response);



        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}