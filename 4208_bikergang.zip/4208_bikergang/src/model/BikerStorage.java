package model;


import java.io.*;
import java.util.HashMap;

public class BikerStorage
{
    private static BikerStorage instance = null;
    private HashMap<String,Biker> bikerMap;
    private final String filename = "bababossbiker.ost";
    
    private BikerStorage() {
        this.bikerMap = new HashMap<>();
    }
    
    public static BikerStorage getInstance() {
        if (instance == null) {
            instance = new BikerStorage();
        }
        return instance;
    }
    
    public void load(){
        try(ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(filename))))
        {
            this.bikerMap = (HashMap<String, Biker>) ois.readObject();
        }catch (FileNotFoundException fnfe){
            System.out.println("Dings, File Not Found. in load()");
        }catch (IOException ioe){
            System.out.println("Digns, IOException. in load()");
        }
        catch (ClassNotFoundException e) {
            System.out.println("Dings, ClassNotFoundException. in load()");
        }
    }
    
    public void save(){
        try(ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(filename)))){
            oos.writeObject(this.bikerMap);
        }catch (FileNotFoundException fnfe){
            System.out.println("Dings, File Not Found. in save()");
        }catch (IOException ioe){
            System.out.println("Digns, IOException. in save()");
        }
    }
    
    public void store(Biker iBiker){
        this.bikerMap.put(iBiker.getMemberNo(),iBiker);
    }
    
    public Biker selectBikerByNo(String memberno){
        return this.bikerMap.get(memberno);
    }
}
