package model;

import javafx.concurrent.Task;

public class BikerSaveTask extends Task<Void> {
    @Override
    protected Void call() throws Exception {
        BikerStorage.getInstance().save();
        return null;
    }
}
