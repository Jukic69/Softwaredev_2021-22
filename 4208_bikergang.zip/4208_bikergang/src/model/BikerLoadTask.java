package model;

import javafx.concurrent.Task;

public class BikerLoadTask extends Task<Void> {
    @Override
    protected Void call() throws Exception {
        BikerStorage.getInstance().load();
        return null;
    }
}
