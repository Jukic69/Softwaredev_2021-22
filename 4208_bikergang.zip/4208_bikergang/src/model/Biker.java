package model;

import javafx.beans.property.*;

import java.io.*;

public class Biker implements Externalizable
{
    private StringProperty memberNo,nick, role, bikeModel;
    
    public String getMemberNo() {return memberNo.get();}
    public String getNick() {return nick.get();}
    public String getRole() {return role.get();}
    public String getBikeModel() {return bikeModel.get();}
    
    public void setMemberNo(String memberNo) {this.memberNo.set(memberNo);}
    public void setNick(String nick) {this.nick.set(nick);}
    public void setRole(String role) {this.role.set(role);}
    public void setBikeModel(String bikeModel) {this.bikeModel.set(bikeModel);}
    
    public Biker(String memberNo, String nick, String role, String bikeModel) {
        this();
        this.memberNo.set(memberNo);
        this.nick.set(nick);
        this.role.set(role);
        this.bikeModel.set(bikeModel);
    }
    
    public Biker() {
        this.memberNo = new SimpleStringProperty();
        this.nick = new SimpleStringProperty();
        this.role = new SimpleStringProperty();
        this.bikeModel = new SimpleStringProperty();
    }
    
    public void find(String memberno){
        Biker iBiker = BikerStorage.getInstance().selectBikerByNo(memberno);
        this.memberNo = iBiker.memberNo;
        this.nick = iBiker.nick;
        this.role = iBiker.role;
        this.bikeModel = iBiker.bikeModel;
    }
    
    public void store(){
        BikerStorage.getInstance().store(this);
    }
    
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(getMemberNo());
        out.writeObject(getNick());
        out.writeObject(getRole());
        out.writeObject(getBikeModel());
    }
    
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        setMemberNo((String) in.readObject());
        setNick((String) in.readObject());
        setRole((String) in.readObject());
        setBikeModel((String) in.readObject());
    }
}
