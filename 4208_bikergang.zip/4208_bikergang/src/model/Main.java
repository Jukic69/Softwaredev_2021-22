package model;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // FXMLLoader erzeugen
        FXMLLoader loader = new FXMLLoader();
    
        // Pfad zum FXML setzen
        loader.setLocation(getClass().getResource("../view/sample.fxml"));
    
        // Root Node laden
        Parent root  = loader.load();
    
        // Referenz auf Controller Objekt
        // Controller controller = loader.getController();
    
        // Gib Controller Referenz auf Programmlogik
        // controller.setProgramLogic(new meineLogikKlasse());
    
        // PrimaryStage konfigurieren und anzeigen
        primaryStage.setResizable(false);
        primaryStage.setTitle("4208_bikergang-saidov-arb");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    
//    @Override
//    public void init() {
//        BikerStorage.getInstance().load();
//    }
//
//    @Override
//    public void stop() throws Exception {
//        super.stop();
//        BikerStorage.getInstance().save();
//    }

    public static void main(String[] args) {
        launch(args);
    }
}
