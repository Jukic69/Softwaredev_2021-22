package controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import model.Biker;
import model.BikerLoadService;
import model.BikerSaveService;
import model.BikerStorage;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable
{
    
    @FXML
    private Button btn_cancel, btn_store, btn_find;
    
    @FXML
    private TextField txt_memberno, txt_nick, txt_role, txt_bikemodel;
    
    Biker actualBiker;
    BikerSaveService bss;
    BikerLoadService bls;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Wenn irgend ein Feld leer ist, so wird btn_store deaktiviert.
        //Wenn txt_memberno leer ist, so wird btn_find deaktiviert.
        //Wenn alle Felder leer sind, sow rid btn_cancel deaktiviert.
        btn_store.disableProperty().bind(txt_memberno.textProperty().isEmpty().or(txt_nick.textProperty().isEmpty().or(txt_role.textProperty().isEmpty().or(txt_bikemodel.textProperty().isEmpty()))));
        btn_find.disableProperty().bind(txt_memberno.textProperty().isEmpty());
        btn_cancel.disableProperty().bind(txt_memberno.textProperty().isEmpty().and(txt_nick.textProperty().isEmpty().and(txt_role.textProperty().isEmpty().and(txt_bikemodel.textProperty().isEmpty()))));

        bss = new BikerSaveService();
        bls = new BikerLoadService();
    }
    
    public void clickOnBtnStore() {
        actualBiker = new Biker(txt_memberno.getText(),txt_nick.getText(),txt_role.getText(),txt_bikemodel.getText());
        actualBiker.store();
    }

    public void clickOnBtnFind() {
        if (BikerStorage.getInstance().selectBikerByNo(txt_memberno.getText()) != null){
            actualBiker = new Biker();
            actualBiker.find(txt_memberno.getText());
            txt_nick.setText(actualBiker.getNick());
            txt_role.setText(actualBiker.getRole());
            txt_bikemodel.setText(actualBiker.getBikeModel());
        }else{
            new Alert(Alert.AlertType.INFORMATION,"This Biker doesn't exist.").show();
        }
    }

    public void clickOnBtnSave() {
//        BikerStorage.getInstance().save();
        bss.restart();
    }

    public void clickOnBtnLoad() {
//        BikerStorage.getInstance().load();
        bls.restart();
    }
    
    public void clickOnBtnCancel(){
        txt_memberno.clear();
        txt_nick.clear();
        txt_role.clear();
        txt_bikemodel.clear();
    }
}
