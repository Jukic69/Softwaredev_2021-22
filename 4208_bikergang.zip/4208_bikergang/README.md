# 4208 Bikergang

Implementiere eine Software mittels JavaFX für die Verwaltung der Mitglieder einer Bikergang.

## Klasse ```Model```

Das Model ist als UML Klassendiagramm vorgegeben.

![Bild1](4209_1.png)

### Attribute:
- ```memberNo```: die Mitgliedsnummer des Bikers (entspricht der Eintrittsreihenfolge), durch die er eindeutig 
- identifiziert wird (Zahl muss mind. 1 Stelle haben)
- ```nick```: Der Spitzname des Members, z.B. "Dirty Harry, Major Tom" (mind. 2 Zeichen)
- ```role```: Die Rolle im Club, z.B. President, Vice Precident, Member, Prospect, ... 
- ```bikeModel```: Motorrad Hersteller und Typ, ist optional (z.B. Harley Davidson Street Glide)
- ALLE Attribute sind als Properties auszuführen!

### Methoden:
- ```find (memberNo)```: sucht den Member aus dem BikerStorage
- ```store()```: speichert den Member in den BikerStorage


## Klasse ```BikerStorage```

Die Persistenz der Bikergang wird über die Klasse BikerStorage erreicht.
BikerStorage speichert die Mitglieder der Bikergang in einer passenden Collection.
Sämtliche Daten werden mittels ObjectStreams persistiert.

### Methoden:
- ```load() / save()```: Speichert bzw. Lädt die Objekte in eine Datei. Der Dateiname ist frei wählbar.
- ```store()```: sichert ein übergebenes Objekt im BikerStorage
- ```selectBikerByNo()```: dient zum Auffinden eines Mitglieds im Catalag anhand seiner Mitgliedsnummer



## Klasse ```BikerGangController```

Die Connection zwischen Model und den angezeigten Daten muss über Bindings erfolgen.
Mittels Bindings wird sichergestellt, dass Buttons nur nach einer Eingabe in die jeweiligen Felder aktiv sind und 
automatisch inaktiv werden.
Wenn keine Member# eingegeben wurde, dann sieht die Anwendung wie folgt aus:

![Bild2](4209_2.png)


![Bild3](4209_3.png)
![Bild4](4209_4.png)

## Buttons:
- ```Cancel``` löscht alle Felder
- ```Find``` findet einen Biker mit der angegebenen MemberID und zeigt diesen an
- ```Store``` speichert den eingegebenen Biker bzw. die Änderungen im BikerStorage (Collection)
- ```Load``` lädt den Bikerstorage aus einer persistierten Datei (ObjectStream)
- ```Save``` persisitiert den Bikerstorage in eine Datei (ObjectStream)

### ACHTUNG:
Das Laden und Speichern erfolgt OHNE die GUI zu blockieren in einem eigenen Thread!

