package client;

import java.io.*;
import java.net.Socket;

public class FirstClient {
    public static void main(String[] args) {
        System.out.println("[client.Client]: Verbindungsaufbau");

        try (Socket serverSocket = new Socket("localhost", 6666);
             DataInputStream dis = new DataInputStream(new BufferedInputStream(serverSocket.getInputStream()));
             DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(serverSocket.getOutputStream()));
        ) {
            System.out.println("[client.Client]: Verbindung hergestellt");
            System.out.println("[client.Client]: Sende Text");

            //  Text an Server schicken
            dos.writeUTF("Thomas");
            dos.flush();

            //Text empfangen
            System.out.println("[client.Client]: Empfangen Text");
            String answer = dis.readUTF();

            System.out.println("[client.Client]: Empfangener Text:" + answer);

        } catch (IOException e) {
            System.out.println("[client.Client]: Irgendwas stimmt nicht mit der Netzwerkverbindung");
        }finally {
            System.out.println("[client.Client]: Verbindung geschlossen!");
        }
    }
}
