package server;

import java.io.IOException;
import java.net.ServerSocket;

public class FirstServer {
    public static void main(String[] args) {
        System.out.println("[Server]: Server gestartet");
        try (ServerSocket listeningSocket = new ServerSocket(6666);) {
            System.out.println("[Server]: Warte auf Client ...");

            //Socket clientSocket = listeningSocket.accept();

            //Übergebe
            new FirstClientHandler(listeningSocket.accept()).communicate();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
