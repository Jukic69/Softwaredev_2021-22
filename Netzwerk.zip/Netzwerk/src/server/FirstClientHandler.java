package server;

import java.io.*;
import java.net.Socket;

public class FirstClientHandler {
    private Socket clientSocket;

    public FirstClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    //Protokoll serverseitig
    void communicate(){
        try (
            DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(clientSocket.getOutputStream()));
            DataInputStream dis = new DataInputStream(new BufferedInputStream(clientSocket.getInputStream()));
        ){
            //  Verbindung erfolgreich - kommuniziere
            //  empfange Text

            System.out.println("[Server]: Empfange Daten");
            String request = dis.readUTF();

            System.out.println("[Server]: Sende Daten");
            String response = "Hallo " + request;
            dos.writeUTF(response);
            dos.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
