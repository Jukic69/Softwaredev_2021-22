package com.company;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Main {

    public static void main(String[] args) {
	//Lösung mit 2 Conditions
        Queue<Integer> queue = new LinkedList<>();
        ReentrantLock lock = new ReentrantLock();
        Condition notFull = lock.newCondition();
        Condition notEmpty = lock.newCondition();
        final int MAX_QUEUE_SIZE = 5;
        Random r = new Random();

        new Producer("Producer 1", queue, lock, notFull, notEmpty, MAX_QUEUE_SIZE).start();

        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        new Consumer("Consumer 1", queue, lock, notFull, notEmpty).start();
        new Consumer("Consumer 2", queue, lock, notFull, notEmpty).start();
        new Consumer("Consumer 3", queue, lock, notFull, notEmpty).start();
    }
}
