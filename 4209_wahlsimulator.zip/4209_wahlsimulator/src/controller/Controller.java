package controller;

import javafx.beans.property.DoubleProperty;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;
import model.WahlService;
import model.Wahlergebnisse;

public class Controller {
    private WahlService wahlService;
    private Wahlergebnisse wahlergebnisse;

    private double[] wahlergebnisseValues;

    public void initialize() {
        DoubleProperty[] properties = {oevp.heightProperty(), spoe.heightProperty(), fpoe.heightProperty(),
                gruene.heightProperty(), neos.heightProperty(), pilz.heightProperty()};

        Label[] labels = {oevpPerC, spoePerC, fpoePerC, gruenePerC, neosPerC, pilzPerC};

        wahlergebnisseValues = new double[]{31.5, 26.9, 26, 3.8, 5.3, 4.4};

        for (int i = 0; i < labels.length; i++) {
            labels[i].setText(String.format("%.2f", wahlergebnisseValues[i]) + "%#");
        }

        wahlergebnisse = new Wahlergebnisse(wahlergebnisseValues, properties);
        wahlergebnisse.bindAllResults();

        wahlService = new WahlService(wahlergebnisse, 0, labels);
        wahlService.setOnSucceeded((e) -> {
            wahlService.reset();
        });

        //Binding of button to schwankungsbreite input
        runButton.disableProperty().bind(schwankungsbreiteField.textProperty().isEmpty().or(wahlService.runningProperty()));
    }

   @FXML
   private TextField schwankungsbreiteField;

    @FXML
    private Rectangle oevp;

    @FXML
    private Rectangle spoe;

    @FXML
    private Rectangle neos;

    @FXML
    private Button runButton;

    @FXML
    private Rectangle fpoe;

    @FXML
    private Rectangle gruene;

    @FXML
    private Rectangle pilz;

    @FXML
    private Label oevpPerC;

    @FXML
    private Label fpoePerC;

    @FXML
    private Label gruenePerC;

    @FXML
    private Label pilzPerC;

    @FXML
    private Label spoePerC;

    @FXML
    private Label neosPerC;

    @FXML
    void runButtonPressed(ActionEvent event) {
        //TODO: run service
        if (!wahlService.isRunning() && wahlService.getState().equals(Worker.State.READY)) {
            wahlService.setSchwankungsbreite(Double.parseDouble(schwankungsbreiteField.getText()));
            wahlService.start();
        } else {
            wahlergebnisse.setWahlergebnisse(wahlergebnisseValues);
            wahlService.setSchwankungsbreite(Double.parseDouble(schwankungsbreiteField.getText()));

            wahlService.restart();
        }
    }
}


