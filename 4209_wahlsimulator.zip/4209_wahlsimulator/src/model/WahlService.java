package model;

import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import javafx.scene.control.Label;

public class WahlService extends ScheduledService<Double> {
    private Wahlergebnisse wahlergebnisse;
    private double schwankungsbreite;
    private Label[] labels;

    public WahlService(Wahlergebnisse wahlergebnisse, int schwankungsbreite, Label[] labels) {
        this.wahlergebnisse = wahlergebnisse;
        this.schwankungsbreite = schwankungsbreite;
        this.labels = labels;
    }

    @Override
    protected Task<Double> createTask() {
        return new WahlTask(wahlergebnisse, schwankungsbreite, labels);
    }

    public void setWahlergebnisse(Wahlergebnisse wahlergebnisse) {
        this.wahlergebnisse = wahlergebnisse;
    }

    public void setSchwankungsbreite(double schwankungsbreite) {
        this.schwankungsbreite = schwankungsbreite;
    }
}
