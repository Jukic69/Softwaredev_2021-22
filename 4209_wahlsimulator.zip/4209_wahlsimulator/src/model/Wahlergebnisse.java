package model;

import javafx.beans.property.DoubleProperty;

public class Wahlergebnisse {
    private double[] wahlergebnisse;
    private DoubleProperty[] properties;

    private final int MULTIPLIER = 2;

    public Wahlergebnisse(double[] wahlergebnisse, DoubleProperty[] properties) {
        this.wahlergebnisse = wahlergebnisse;
        this.properties = properties;
    }

    public double getWahlergebnis(int i) {
        return wahlergebnisse[i];
    }

    public void bindAllResults() {
        for (int i = 0; i < wahlergebnisse.length; i++) {
            properties[i].set(wahlergebnisse[i]*MULTIPLIER);
        }
    }

    public void bindAllResultsToZero() {
        for (int i = 0; i < wahlergebnisse.length; i++) {
            properties[i].set(0);
        }
    }

    public void bindResult(int i, double val) {
        properties[i].set(val*MULTIPLIER);
    }

    public DoubleProperty getProperty(int i) {
        return properties[i];
    }

    public void setWahlergebnisse(double[] wahlergebnisse) {
        this.wahlergebnisse = wahlergebnisse;
    }

    public int getLength() {
        return wahlergebnisse.length;
    }
}
