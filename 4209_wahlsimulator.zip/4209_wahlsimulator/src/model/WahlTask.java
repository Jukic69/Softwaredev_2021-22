package model;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.scene.control.Label;

import java.util.Random;

public class WahlTask extends Task<Double> {
    private Wahlergebnisse wahlergebnisse;
    private double schwankungsbreite;
    private Label[] labels;

    public WahlTask(Wahlergebnisse wahlergebnisse, double schwankungsbreite, Label[] labels) {
        this.wahlergebnisse = wahlergebnisse;
        this.schwankungsbreite = schwankungsbreite;
        this.labels = labels;
    }

    @Override
    protected Double call() throws Exception {
        wahlergebnisse.bindAllResultsToZero();
        setNewWahlergebnisse();
        resetLabels();

        for (int i = 0; i < wahlergebnisse.getLength(); i++) {
            wahlergebnisse.getProperty(i).set(0);

            for (double j = 0; j < wahlergebnisse.getWahlergebnis(i); j+=0.1) {
                wahlergebnisse.bindResult(i, j);

                Thread.sleep(10);
            }

            Thread.sleep(1000);
        }

        int i = 0;

        for (i = 0; i < wahlergebnisse.getLength(); i++) {
            int j = i;

            //Besser mit text properties
            Platform.runLater(() -> {
                labels[j].setText(String.format("%.2f", wahlergebnisse.getWahlergebnis(j)) + "%");
            });

            Thread.sleep(300);
        }

        return (double)wahlergebnisse.getLength();
    }


    private void setNewWahlergebnisse() {
        double[] wahlergebnisseNew = new double[wahlergebnisse.getLength()];

        Random random = new Random();

        for (int i = 0; i < wahlergebnisse.getLength(); i++) {
            wahlergebnisseNew[i] = wahlergebnisse.getWahlergebnis(i) + random.nextDouble()*2*schwankungsbreite - schwankungsbreite;

            if (wahlergebnisseNew[i] < 0) {
                i--;
            }
        }

        wahlergebnisse.setWahlergebnisse(wahlergebnisseNew);
    }

    private void resetLabels() {
        for (int i = 0; i < labels.length; i++) {
            int j = i;

            Platform.runLater(() -> {
                labels[j].setText("");
            });
        }
    }
}
