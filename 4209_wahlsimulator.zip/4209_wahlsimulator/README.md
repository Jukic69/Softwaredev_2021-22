# 4209_WahlSimulator

Entwickle eine animierte Wahlsimulation der NR-Wahl 2019 mit JavaFX unter **Verwendung von MVC**.

Als Ausgangsbasis für die Simulation werden die Wahlergebnisse aus dem Jahr 2017 herangezogen (siehe Prozentwerte
in der Grafik). Zu Beginn wird das Wahlergebnis aus 2019 eingeblendet.
* ÖVP: 31,5%
* SPÖ: 26,9% 
* FPÖ: 26,0% 
* Grüne: 3,8% 
* Neos: 5,2% 
* Pilz: 4,4%


Der User kann eine Schwankungsbreite angeben. 
* Anhand dieses Wertes werden die neuen Wahlergebnisse per Zufall berechnet.
* Eine Schwankungsbreite von 5% bedeutet, dass das zu erwartende Ergebnis bei jeder Partei +/- 5% liegt. 
  
Das Ergebnis ist zufällig innerhalb dieser Schwankung zu bestimmen.

Sobald der User Start drückt, werden alle Wahlergebnisse gelöscht und die Animation startet nach Ablauf einer Sekunde. 
Anschließend werden die Balkendiagramme langsam je Partei aktualisiert, wobei wiederum eine Pause von 1s zwischen den 
einzelnen Parteiergebnissen einzuhalten ist. 

Erst nach Ende dieser Vorgang abgeschlossen ist, werden die Prozentwerte eingeblendet.

## Screenshots

Nach dem Programmstart:
![Screenshot1](4209_1.png)

Während der Simulation: 
![Screenshot2](4209_2.png)

Nach Ende der Simulation:
![Screenshot3](4209_3.png)



## Aufgaben
* Die Schwankungsbreite kann vom User bestimmt werden (Eingabefeld „Schwankungsbreite“).
* Die Wahlergebnisse sind in einer eigenen Datenklasse (gemäß MVC mit Properties) die zu verwalten (Wahl.java).
* Löse folgende Aufgaben mit Bindings:
  * Start Button ist nur aktiv, wenn eine Schwankungsbreite eingegeben wurde
  * Wahlergebnis ist in Echtzeit zu aktualisieren (verwende Rectangle), die Höhe der Balken ist für die Ansicht zu verdoppeln!
* Das Ergebnis der Simulation (prozentuelles Vorkommens der Würfel) ist unmittelbar NACH Ende der Simulation anzuzeigen (Eventhandler!).
* Die Simulation kann mehrfach gestartet werden, sie läuft nebenläufig!


## Punkte ( 20 / ___ )
* ( 4 / ___ ) MVC inkl. Datenklasse smat Properties
* ( 3 / ___ ) korrekte Bindindings
* ( 4 / ___ ) Wahlsimulation (Berechnung)
* ( 4 / ___ ) Wahlsimulation (Concurrent, Task/Service)
* ( 2 / ___ ) Anzeige des Sim.Ergebnisses (Prozent)
* ( 3 / ___ ) GUI inkl. Ereignisbehandlung